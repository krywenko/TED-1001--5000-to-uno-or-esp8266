#!/usr/bin/perl -w -s

system("stty -F /dev/ttyUSB0 1200 cs8 raw");

open INFILE, "/dev/ttyUSB0"
   or die "\nCannot open /dev/ttyUSB0!\n";
   
use GD::Graph::hbars;
 $live = 0;
 $cnt2 = 0;

@data = ();
$buf = "";
$begin = 0;
$started = 0;
sub processPacket($);

while (read(INFILE, $buf, 1)) {
  $d = ord($buf) ^ 0xff;
  if ($d == 0x55 && $started == 0) {
    $started = 1;
    $a = 0;
   
  }
  if ($started == 1) {
    $data[$a] = $d;
    $sum += $data[$a];
     printf("0x%02X ", $data[$a]);
    $a++;
        if ($a >= 11) {
      $sum -= $data[9];
      $sum &= 0xff;
      if ($sum == 0) { processPacket($data); }
      $started=1;
      $a = 0;     
    }
    
  }
  if ( $begin <= 22) {
  $cnt = ($begin + 1);
  $begin = $cnt;}
  # print "$begin bit ";
  if ($begin >= 23) {close INFILE;}
}

  # Working sub process packet stuff
  sub processPacket($) {
  local($data) = @_;
    # your personal setup info
  # $dir= ted data folder - $ted = name of ted rrd file
  $dir = '/home/owner/';
  # $www = '/var/www/';
  $ted = 'ted';
  $ted1 = 'ted1';
  $ted2 = 'ted2';
  
  $mtu = $data[1];
  # the $mtu equals your mtu number put in a Decimal to Hexadecimal Converter )
  if ($begin <=  22) {
  $begin = 1;
  if ($mtu == 0xCE ) {
  #  If the power reading is way off, uncomment the other power line
   $p = (($data[5]^0xff)<<8) + ($data[4]^0xff);
   # print "$p ";
   $pa = ($data[5]<<8) + $data[4];
   # print "$pa ";
  if ($p <= 5000) {
  $voltage = ($data[8] << 8) | $data[7];
  $voltage = sprintf("%.3f",123.6 + ($voltage - 27620) / 85 * 0.2);
  $p = sprintf("%.3f",(1.19 + 0.84 * (($p - 288.0) / 204.0)));
  @tda = localtime(time);
  $td = ($tda[4]+1)."/$tda[3]/".(1900+$tda[5])." $tda[2]:$tda[1]:$tda[0]";
  print "$td, Hydro $p, Voltage $voltage\n";
  system("rrdtool updatev $dir/$ted.rrd N:$p:$voltage");
  $begin = 0;
  }
  if ($pa <= 5000) {
  # $power = ($data[5]<<8) + $data[4];
  $voltage = ($data[8] << 8) | $data[7];
  $voltage = sprintf("%.3f",123.6 + ($voltage - 27620) / 85 * 0.2);
  $pa = sprintf("%.3f",(0 - (1.19 + 0.84 * (($pa - 288.0) / 204.0))));
  @tda = localtime(time);
  $td = ($tda[4]+1)."/$tda[3]/".(1900+$tda[5])." $tda[2]:$tda[1]:$tda[0]";
  print "$td, Hydro $pa, Voltage $voltage\n";
  system("rrdtool updatev $dir/$ted.rrd N:$pa:$voltage");
  $begin = 0;
  }
  }
  
   if ($mtu == 0xA0 ) {
  #  If the power reading is way off, uncomment the other power line
   $w = (($data[5]^0xff)<<8) + ($data[4]^0xff);
   # print "$w ";
   $wa = ($data[5]<<8) + $data[4];
   # print "$wa ";
  if ($w <= 5000) {
  $voltage1 = ($data[8] << 8) | $data[7];
  $voltage1 = sprintf("%.3f",123.6 + ($voltage1 - 27620) / 85 * 0.2);
  $w = sprintf("%.3f",(1.19 + 0.84 * (($w - 288.0) / 204.0)));
  @tda = localtime(time);
  $td = ($tda[4]+1)."/$tda[3]/".(1900+$tda[5])." $tda[2]:$tda[1]:$tda[0]";
  print "$td, Wind $w, Voltage $voltage1\n";
  system("rrdtool updatev $dir/$ted2.rrd N:$w:$voltage1");
  $begin = 0;
  }
  if ($wa <= 5000) {
  # $power = ($data[5]<<8) + $data[4];
  $voltage1 = ($data[8] << 8) | $data[7];
  $voltage1 = sprintf("%.3f",123.6 + ($voltage1 - 27620) / 85 * 0.2);
  $wa = sprintf("%.3f",(0 - (1.19 + 0.84 * (($wa - 288.0) / 204.0))));
  @tda = localtime(time);
  $td = ($tda[4]+1)."/$tda[3]/".(1900+$tda[5])." $tda[2]:$tda[1]:$tda[0]";
  print "$td, Wind $wa, Voltage $voltage1\n";
  system("rrdtool updatev $dir/$ted2.rrd N:$wa:$voltage1");
  $begin = 0;
  }
  }
    if ($mtu == 0xB1 ) {
  #  If the power reading is way off, uncomment the other power line
   $s = (($data[5]^0xff)<<8) + ($data[4]^0xff);
   # print "$s ";
   $sa = ($data[5]<<8) + $data[4];
   # print "$sa ";
  if ($s <= 5000) {
  $voltage2 = ($data[8] << 8) | $data[7];
  $voltage2 = sprintf("%.3f",123.6 + ($voltage2 - 27620) / 85 * 0.2);
  $s = sprintf("%.3f",(1.19 + 0.84 * (($s - 288.0) / 204.0)));
  @tda = localtime(time);
  $td = ($tda[4]+1)."/$tda[3]/".(1900+$tda[5])." $tda[2]:$tda[1]:$tda[0]";
  print "$td, Solar $s, Voltage $voltage2\n";
  system("rrdtool updatev $dir/$ted1.rrd N:$s:$voltage2");
  $begin = 0;
  }
  if ($sa <= 5000) {
  # $power = ($data[5]<<8) + $data[4];
  $voltage2 = ($data[8] << 8) | $data[7];
  $voltage2 = sprintf("%.3f",123.6 + ($voltage2 - 27620) / 85 * 0.2);
  $sa = sprintf("%.3f",(0 - (1.19 + 0.84 * (($sa - 288.0) / 204.0))));
  @tda = localtime(time);
  $td = ($tda[4]+1)."/$tda[3]/".(1900+$tda[5])." $tda[2]:$tda[1]:$tda[0]";
  print "$td, Solar $sa, Voltage $voltage2\n";
  system("rrdtool updatev $dir/$ted1.rrd N:$sa:$voltage2");
  $begin = 0;
  }
  }
  
 if ( $live <= 5) {
  $cnt2 = ($live + 1);
  $live = $cnt2;}
  
  if ($live >= 6) {
  $cnt2 = 0 ;
  $live = 0;
my $g = GD::Graph::hbars->new(543,100) or die GD::Graph->error;

my @data1 = (['  '],[$voltage]);
my $colour = '#437008';

if ($voltage >= 128) { $colour = '#760F08'};
if ($voltage <= 120) { $colour = '#f6ef0a'};
$g->set(
     y_label           => 'Current voltage',
     transparent       => 0,
     valuesclr         => '#000000',
     legendclr         => '#000000',
     legend_placement  => 'BL',
     bar_width         => 30,
     y_max_value       => '200',
     y_tick_number     => '10',
     y_label_skip      => '2',
     title             => 'Voltage',
     show_values       => 1, 
     dclrs             => [$colour]
 ) or die $g->error;
$g->set_values_font('/usr/share/fonts/truetype/ttf-dejavu/DejaVuSans-Bold.ttf', 16);
$g->set_legend_font('fonts/DejaVuSans.ttf', 7);
$g->set_title_font('/usr/share/fonts/truetype/ttf-dejavu/DejaVuSans-Bold.ttf', 16);

my $gd = $g->plot(\@data1) or die $g->error;

unlink '/var/www/voltage.gif';
open(IMG, '>/var/www/voltage.gif') or die $!;
  binmode IMG;
  print IMG $gd->gif;
close IMG;

my $g1 = GD::Graph::hbars->new(543,100) or die GD::Graph->error;

my @data2 = (['  '],[$p]);
 $colour = '#437008';

if ($p >= 5) { $colour = '#f6ef0a'};
if ($p >= 10) { $colour = '#760F08'};

$g1->set(
     y_label           => 'Current KW usage',
     transparent       => 0,
     valuesclr         => '#000000',
     legendclr         => '#000000',
     legend_placement  => 'BL',
     bar_width         => 30,
     y_max_value       => '15',
     y_tick_number     => '10',
     y_label_skip      => '2',
     title             => 'Kilowatts',
     show_values       => 1, 
     dclrs             => [$colour]
 ) or die $g1->error;
$g1->set_values_font('/usr/share/fonts/truetype/ttf-dejavu/DejaVuSans-Bold.ttf', 16);
$g1->set_legend_font('fonts/DejaVuSans.ttf', 7);
$g1->set_title_font('/usr/share/fonts/truetype/ttf-dejavu/DejaVuSans-Bold.ttf', 16);

my $gd2 = $g1->plot(\@data2) or die $g1->error;

unlink '/var/www/power.gif';
open(IMG, '>/var/www/power.gif') or die $!;
  binmode IMG;
  print IMG $gd2->gif;
close IMG;

print "update";
}

 }
 else {close INFILE;}
  }
  
close INFILE;
